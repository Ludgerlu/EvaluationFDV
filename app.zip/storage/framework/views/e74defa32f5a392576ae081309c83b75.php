

<?php $__env->startSection('type' ,  Auth::user()->type ); ?>


<?php $__env->startSection('header'); ?>

<div class="col-12">
    <p
        class="fs-1 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e(Auth::user()->type); ?> <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?></b> 
    </p>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row mb-3">
        <div class="col-md-6  mb-3">
            <div class="card border-0 stats-card ">
                <div class="card-body text-center ">
                    <a href="<?php echo e(route('password')); ?>" class="btn btn-danger btn-sm w-100 h-100 text-uppercase">
                        Changer de Mot de passe
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-6  mb-3">
            <div class="card border-0 stats-card ">
                <div class="card-body text-center ">
                    <a href="<?php echo e(route('password.default')); ?>" class="btn btn-danger btn-sm w-100 h-100 text-uppercase">
                        Mot de passe par Défaut
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- info psv -->
    <div class="card mb-3">
        <div class="card-header d-flex justify-content-between">
            <h5 class="card-title">
                <a href="<?php echo e($link); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left"></i> 
                    Accueil
                </a> 
           </h5>
        </div>
        <div class="card-body">  
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?> 
            <div class="mb-3 row">
                <div class="col-12 col-md-3"><label for="fld-login" class="form-label">Matricule</label></div>
                <div class="col-12 col-md-9"><input type="text" class="form-control" id="fld-login" name="fld-login" value="<?php echo e($user->matricule); ?>" readonly/></div>
            </div>  
            <div class="mb-3 row">
                <div class="col-12 col-md-3"><label for="fld-login" class="form-label">Login</label></div>
                <div class="col-12 col-md-9"><input type="text" class="form-control" id="fld-login" name="fld-login" value="<?php echo e($user->login); ?>" readonly/></div>
            </div>
            <div class="mb-3 row">
                <div class="col-12 col-md-3"><label for="fld-login" class="form-label">Prénom</label></div>
                <div class="col-12 col-md-9"><input type="text" class="form-control" id="fld-login" name="fld-login" value="<?php echo e($user->surname); ?>" readonly/></div>
            </div>
            <div class="mb-3 row">
                <div class="col-12 col-md-3"><label for="fld-lastname" class="form-label">Nom</label></div>
                <div class="col-12 col-md-9">
                    <input type="text" class="form-control" id="fld-lastname" name="fld-lastname" value="<?php echo e($user->name); ?>" readonly/>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="col-12 col-md-3"><label for="fld-fk_usertype" class="form-label">Type</label></div>
                <div class="col-12 col-md-9">
                    <input type="text" class="form-control" id="fld-fk_usertype" name="fld-fk_usertype" value="<?php echo e($user->type); ?>" readonly/>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="col-12 col-md-3"><label for="fld-fk_service" class="form-label">Service</label></div>
                <div class="col-12 col-md-9">
                    <input type="text" class="form-control" id="fld-fk_service" name="fld-fk_service" value="<?php echo e($user->service[0]->sce_ccial); ?>" readonly/>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/profile/index.blade.php ENDPATH**/ ?>