

<?php $__env->startSection('header'); ?>

<div class="col-12">
    <p
        class="fs-2 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e(Auth::user()->type); ?> <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?></b> 
    </p>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
    <div class="container">
        
        <div class="card">
            <div
                class="card-header d-flex justify-content-between align-items-center"
            >
                <h5 class="mb-0">Détail Note</h5>
            </div>

            <div class="card-body table-responsive-lg">
                <table id="pdvTable" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Region</th>
                            <th>Service</th>
                            <th>Type</th>
                            <th>Evaluateur</th>
                            <th>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user['type'] !== 'DR' && $user['type'] !== 'CDC TT'): ?>
                                <?php
                                    // Get the latest evaluation
                                    $latestEvaluation = !empty($user['evaluation']) ? collect($user['evaluation'])->first() : null;
                                ?>

                                <tr>
                                    <td><?php echo e($user['name']); ?></td>
                                    <td><?php echo e($user['region']); ?></td>
                                    <td><?php echo e($user['service']); ?></td>
                                    <td><?php echo e($user['type']); ?></td>

                                    <?php if($latestEvaluation): ?>
                                        <td><?php echo e($latestEvaluation['creator'] == $user['name'] ? 'Auto' : $latestEvaluation['creator']); ?></td>
                                        <td><?php echo e($latestEvaluation['score']); ?> / 20</td>
                                    <?php else: ?>
                                        <td>-</td>
                                        <td>-</td>
                                    <?php endif; ?>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo e($user['name']); ?></td>
                                    <td><?php echo e($user['region']); ?></td>
                                    <td>N/A</td>
                                    <td><?php echo e($user['type']); ?></td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/admin/users/rapport.blade.php ENDPATH**/ ?>