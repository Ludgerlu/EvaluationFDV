


<?php $__env->startSection('header'); ?>

<div class="col-12">
    <p
        class="fs-2 mb-3 text-center"
        style="font-family: 'Montserrat', sans-serif"
    >
        <b>ACTIVITÉS <?php echo e(Auth::user()->type); ?> <?php echo e(Auth::user()->surname); ?> <?php echo e(Auth::user()->name); ?></b> 
    </p>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row mb-3">
        <div class="col-md-2  mb-3">
            <div class="card border-0 stats-card">
                <div class="card-body text-center">
                    <a href="<?php echo e(route('csc.dashboard')); ?>" class="text-decoration-none text-sabc-gray">
                        <i class="bi bi-arrow-left"></i> Retour
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card border-0 stats-card">
                <div class="card-body">
                    <p class="mb-0"> <span class="text-sabc-gray">Service commercial :</span> <?php echo e(json_decode(Auth::user()->service)[0]->sce_ccial); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-5">
            <div class="card border-0 stats-card">
                <div class="card-body">
                    <p class="mb-0">Region : <span class="text-sabc-gray"> <?php echo e(session('user_region')); ?></span></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="card">
        <div
            class="card-header d-flex justify-content-between align-items-center"
        >
            <h5 class="mb-0">Notes</h5>
            <a
                class="btn btn-danger btn-sm"
                href="<?php echo e(route('cdv.note.create')); ?>"
            >
                Evaluer
            </a>
        </div>
        <div class="card-body">
            <table id="mdTable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Type</th>
                        <th>Note</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $evaluations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($evaluation->creator->surname); ?></td>
                            <td><?php echo e($evaluation->creator->type); ?></td>
                            <td><?php echo e($evaluation->total); ?>%</td>
                            <td><?php echo e($evaluation->created_at->format('d/m/Y H:i')); ?></td>
                            <td>
                                <a href="<?php echo e(route('cdv.note.show', $evaluation->id_note)); ?>" class="btn btn-sm btn-primary">
                                    Détails
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\digex\p-nam\resources\views/cdv/index.blade.php ENDPATH**/ ?>